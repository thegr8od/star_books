export const users = [
    {
      email: "john@example.com",
      password: "12345"
    },
    {
      email: "jane@company.com",
      password: "password123"
    },
    {
      email: "test@test.com",
      password: "testpass"
    }
  ];