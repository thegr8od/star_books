const data = { 
  x: 5,
  y: 5,}

export default data;