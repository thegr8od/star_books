// API URL
export const API_URL = "https://starbooks.site/api";
// export const API_URL = "http://localhost:9090/api";
export const CONTENT_TYPE_JSON = "application/json";
// export const API_URL = "https://i12d206.p.ssafy.io/api";
